/**
 * AI 功能检测器
 * 检测 localhost:5000 代理服务器是否可用
 */
(function() {
    'use strict';
    
    var AI_API_BASE = 'http://localhost:5000/api';
    var AI_CHECK_TIMEOUT = 2000;
    
    window.__AI_ENABLED__ = false;
    window.__AI_API_BASE__ = null;
    
    function checkAIAvailable() {
        return new Promise(function(resolve) {
            var controller = new AbortController();
            var timeoutId = setTimeout(function() { controller.abort(); }, AI_CHECK_TIMEOUT);
            
            fetch(AI_API_BASE + '/health', {
                method: 'GET',
                mode: 'cors',
                signal: controller.signal
            })
            .then(function(response) {
                clearTimeout(timeoutId);
                resolve(response.ok);
            })
            .catch(function() {
                clearTimeout(timeoutId);
                resolve(false);
            });
        });
    }
    
    function initAIDetection() {
        checkAIAvailable().then(function(isAvailable) {
            if (isAvailable) {
                window.__AI_ENABLED__ = true;
                window.__AI_API_BASE__ = AI_API_BASE;
                console.log('[AI检测] 代理服务器可用');
            } else {
                window.__AI_ENABLED__ = false;
                window.__AI_API_BASE__ = null;
                console.log('[AI检测] 代理服务器不可用');
                
                var btn = document.getElementById('ai-float-btn');
                if (btn) btn.style.display = 'none';
                
                var panel = document.getElementById('ai-sidepanel');
                if (panel) panel.style.display = 'none';
            }
            
            document.dispatchEvent(new CustomEvent('ai-status-ready'));
        });
    }
    
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initAIDetection);
    } else {
        initAIDetection();
    }
})();
