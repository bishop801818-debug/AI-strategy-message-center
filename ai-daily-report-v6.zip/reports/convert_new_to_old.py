#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
转换脚本：将新的9个事业部JSON文件转换为旧的单一日期JSON格式
新格式：C:/Users/1/Downloads/2026-05-19-9bu-reports-json/*.json (9个文件)
旧格式：D:/trae/AI Daily report/reports/YYYY-MM-DD.json (1个文件)

使用方法：
    python convert_new_to_old.py [日期] [源目录]
    例：python convert_new_to_old.py 2026-05-19 C:/Users/1/Downloads/2026-05-19-9bu-reports-json
"""

import json
import os
import sys
from datetime import datetime

# 配置路径
REPORTS_DIR = r"D:\trae\AI Daily report\reports"

# 新JSON文件到旧部门代码的映射
FILE_TO_DEPT = {
    "01-润滑油事业部.json": "lhy",
    "02-可兰素事业部.json": "kls",
    "03-常州锂源事业部.json": "czly",
    "04-龙蟠时代事业部.json": "lpsd",
    "05-山东美多事业部.json": "sdmd",
    "06-三金锂电事业部.json": "sjld",
    "07-铂源催化事业部.json": "bych",
    "08-法恩莱特事业部.json": "felt",
    "09-迪克化学事业部.json": "dhx",
}

def convert_section_items(new_items, dim):
    """将新格式的items转换为旧格式的items"""
    old_items = []

    if dim == "topnews":
        # 新格式：今日关注 是字符串列表
        for text in new_items:
            old_items.append({
                "title": text[:100] + "..." if len(text) > 100 else text,
                "content": text,
                "priority": "P2",
                "source": "",
                "url": "",
                "date": "",
                "raw": text
            })

    elif dim == "市场":
        # 市场_价格结构特殊，由convert_market_section单独处理
        pass

    elif dim in ["政策", "竞品", "前沿", "客户", "项目"]:
        # 新格式：政策_行业/企业动态/技术_产品/项目_招标 是对象列表
        for item in new_items:
            if isinstance(item, dict):
                old_items.append({
                    "title": item.get("标题", ""),
                    "content": item.get("正文", ""),
                    "priority": "P2",
                    "source": item.get("来源", ""),
                    "url": "",
                    "date": item.get("日期", ""),
                    "raw": item.get("正文", "")[:200] + "..." if len(item.get("正文", "")) > 200 else item.get("正文", "")
                })

    return old_items

def convert_market_section(market_data):
    """转换市场_价格部分为旧格式"""
    items = []

    # 处理 price_table
    if "price_table" in market_data:
        for pt in market_data["price_table"]:
            品类 = pt.get("品类", "")
            价格 = pt.get("价格", "")
            涨跌 = pt.get("涨跌", "")
            来源 = pt.get("来源", "")
            content = f"{品类}：{价格}（{涨跌}）来源：{来源}"
            items.append({
                "title": f"{品类} {价格}",
                "content": content,
                "priority": "P2",
                "source": 来源,
                "url": "",
                "date": "",
                "raw": content
            })

    # 处理 供给信号
    if "供给信号" in market_data:
        for signal in market_data["供给信号"]:
            items.append({
                "title": signal[:50] + "..." if len(signal) > 50 else signal,
                "content": signal,
                "priority": "P2",
                "source": "",
                "url": "",
                "date": "",
                "raw": signal
            })

    # 处理 争议风险
    if "争议风险" in market_data:
        for risk in market_data["争议风险"]:
            items.append({
                "title": risk[:50] + "..." if len(risk) > 50 else risk,
                "content": risk,
                "priority": "P2",
                "source": "",
                "url": "",
                "date": "",
                "raw": risk
            })

    return items

def convert_new_json_to_old_dept(new_data, dept_code):
    """将一个新格式JSON转换为旧格式的部门对象"""

    header = new_data.get("header", {})
    sections = new_data.get("sections", {})

    # 提取基本信息
    dept_name = header.get("事业部", "")
    report_date = header.get("报告时间", "")
    coverage = header.get("覆盖范围", "")

    # 提取专属提示
    tips = sections.get("专属提示", {})
    opportunities = tips.get("机会", [])
    risks = tips.get("风险", [])
    suggestions = tips.get("行动建议", [])
    focuses = tips.get("重点关注", [])

    # 构建 headline (从今日关注第一条提取)
    topnews = sections.get("今日关注", [])
    headline = topnews[0][:100] if topnews else f"{dept_name}早报"

    # 构建 lead_judgment (行动建议 + 重点关注)
    lead_judgment = "；".join(suggestions + focuses) if (suggestions or focuses) else ""

    # 构建 risk_tip (风险)
    risk_tip = "；".join(risks) if risks else ""

    # 构建 summary (机会)
    summary = "；".join(opportunities) if opportunities else ""

    # 构建 sections 列表（旧格式）
    old_sections = []

    # 1. 今日关注 → topnews
    if "今日关注" in sections:
        old_sections.append({
            "dim": "topnews",
            "title": "今日关注",
            "items": convert_section_items(sections["今日关注"], "topnews")
        })

    # 2. 市场_价格 → 市场
    if "市场_价格" in sections:
        market_items = convert_market_section(sections["市场_价格"])
        old_sections.append({
            "dim": "市场",
            "title": "市场_价格",
            "items": market_items
        })

    # 3. 政策_行业 → 政策
    if "政策_行业" in sections:
        old_sections.append({
            "dim": "政策",
            "title": "政策_行业",
            "items": convert_section_items(sections["政策_行业"], "政策")
        })

    # 4. 企业动态 → 竞品
    if "企业动态" in sections:
        old_sections.append({
            "dim": "竞品",
            "title": "企业动态",
            "items": convert_section_items(sections["企业动态"], "竞品")
        })

    # 5. 技术_产品 → 前沿
    if "技术_产品" in sections:
        old_sections.append({
            "dim": "前沿",
            "title": "技术_产品",
            "items": convert_section_items(sections["技术_产品"], "前沿")
        })

    # 6. 项目_招标 → 项目
    if "项目_招标" in sections:
        old_sections.append({
            "dim": "项目",
            "title": "项目_招标",
            "items": convert_section_items(sections["项目_招标"], "项目")
        })

    # 计算总事件数
    total_events = sum(len(s.get("items", [])) for s in old_sections)

    # 构建部门对象（旧格式）
    dept_obj = {
        "name": dept_name,
        "subtitle": f"{dept_name}早报",
        "report_date": report_date,
        "window_start": report_date,
        "window_end": report_date,
        "headline": headline,
        "lead_judgment": lead_judgment,
        "risk_tip": risk_tip,
        "summary": summary,
        "sections": old_sections,
        "sectionsByDim": {},  # 暂时为空
        "total_events": total_events
    }

    return dept_obj

def main():
    # 解析命令行参数
    if len(sys.argv) < 2:
        date_str = datetime.now().strftime("%Y-%m-%d")
    else:
        date_str = sys.argv[1]

    if len(sys.argv) < 3:
        src_dir = r"C:\Users\1\Downloads\2026-05-19-9bu-reports-json"
    else:
        src_dir = sys.argv[2]

    print(f"[转换] 日期: {date_str}")
    print(f"[转换] 源目录: {src_dir}")
    print(f"[转换] 目标目录: {REPORTS_DIR}")
    print()

    # 检查源目录
    if not os.path.exists(src_dir):
        print(f"[错误] 源目录不存在: {src_dir}")
        return False

    # 读取所有新JSON文件并转换
    departments = {}
    for filename, dept_code in FILE_TO_DEPT.items():
        filepath = os.path.join(src_dir, filename)
        if not os.path.exists(filepath):
            print(f"[警告] 文件不存在: {filename}，跳过")
            continue

        try:
            with open(filepath, 'r', encoding='utf-8') as f:
                new_data = json.load(f)

            dept_obj = convert_new_json_to_old_dept(new_data, dept_code)
            departments[dept_code] = dept_obj
            print(f"[OK] 已转换: {filename} → {dept_code}")

        except Exception as e:
            print(f"[错误] 转换失败 {filename}: {e}")
            import traceback
            traceback.print_exc()

    if not departments:
        print("[错误] 没有成功转换任何部门")
        return False

    # 构建旧格式JSON
    old_data = {
        "date": date_str,
        "generated_at": datetime.now().isoformat(),
        "window_start": date_str,
        "window_end": date_str,
        "version": f"convert_new_to_old.py - {date_str}",
        "total_divisions": len(departments),
        "departments": departments
    }

    # 保存为目标文件
    target_file = os.path.join(REPORTS_DIR, f"{date_str}.json")
    with open(target_file, 'w', encoding='utf-8') as f:
        json.dump(old_data, f, ensure_ascii=False, indent=2)

    print(f"\n[OK] 已保存: {target_file}")
    print(f"[统计] 部门数: {len(departments)}")

    # 更新 index.json
    index_file = os.path.join(REPORTS_DIR, "index.json")
    if os.path.exists(index_file):
        with open(index_file, 'r', encoding='utf-8') as f:
            index_data = json.load(f)

        if date_str not in index_data.get('available_dates', []):
            index_data['available_dates'].insert(0, date_str)

        index_data['latest_date'] = date_str
        index_data['generated_at'] = datetime.now().isoformat()
        index_data['total_reports'] = len(index_data.get('available_dates', []))

        with open(index_file, 'w', encoding='utf-8') as f:
            json.dump(index_data, f, ensure_ascii=False, indent=2)

        print(f"[OK] 已更新 index.json")
        print(f"[统计] 最新日期: {index_data['latest_date']}")
        print(f"[统计] 总报告数: {index_data['total_reports']}")

    print("\n[完成] 转换成功！")
    print(f"[提示] 请刷新浏览器 http://localhost:8888/index_v3.html 查看更新")

    return True

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)
