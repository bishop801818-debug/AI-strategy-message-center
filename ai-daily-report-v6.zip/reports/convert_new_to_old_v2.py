#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
转换脚本 v2：将新的9个事业部JSON文件转换为旧的单一日期JSON格式
新格式：C:/Users/1/Downloads/2026-05-19-9bu-reports-json/*.json (9个文件)
旧格式：D:/trae/AI Daily report/reports/YYYY-MM-DD.json (1个文件)

旧格式结构：
{
  "date": "2026-05-19",
  "departments": {
    "czly": {
      "name": "常州锂源事业部",
      "subtitle": "...",
      "sections": [
        {"title": "今日关注", "name": "今日关注", "content": "markdown_string"},
        {"title": "市场行情", "name": "市场行情", "content": "markdown_string_with_table"},
        {"title": "政策风向", "name": "政策风向", "content": "markdown_string"},
        {"title": "🔥 企业动态", "name": "🔥 企业动态", "content": "markdown_string"},
        {"title": "前沿与产品动态", "name": "前沿与产品动态", "content": "markdown_string"},
        {"title": "项目与招标", "name": "项目与招标", "content": "markdown_string"},
        {"title": "【常州锂源事业部专属提示】", "name": "【常州锂源事业部专属提示】", "content": "markdown_string"}
      ],
      ...
    }
  }
}

使用方法：
    python convert_new_to_old_v2.py [日期] [源目录]
"""

import json
import os
import sys
from datetime import datetime

# 配置路径
REPORTS_DIR = r"D:\trae\AI Daily report\reports"

# 新JSON文件到旧部门代码的映射
FILE_TO_DEPT = {
    "01-润滑油事业部.json": "lhy",
    "02-可兰素事业部.json": "kls",
    "03-常州锂源事业部.json": "czly",
    "04-龙蟠时代事业部.json": "lpsd",
    "05-山东美多事业部.json": "sdmd",
    "06-三金锂电事业部.json": "sjld",
    "07-铂源催化事业部.json": "bych",
    "08-法恩莱特事业部.json": "felt",
    "09-迪克化学事业部.json": "dhx",
}

def generate_topnews_content(items):
    """生成今日关注的Markdown内容（新格式：items为[{序号, 标题}]）"""
    return "\n\n".join(item.get("标题", "") for item in items)

def generate_market_content(market_data):
    """生成市场行情的Markdown内容（新格式：价格数据表/供给信号/争议风险）"""
    lines = []

    # 1. 价格数据表
    if "价格数据表" in market_data and market_data["价格数据表"]:
        lines.append("| 产品 | 价格 | 涨跌 | 来源 |")
        lines.append("|------|------|------|------|")
        for pt in market_data["价格数据表"]:
            品类 = pt.get("品类", "")
            价格 = pt.get("价格", "")
            涨跌 = pt.get("涨跌", "")
            来源 = pt.get("来源", "")
            lines.append(f"| {品类} | {价格} | {涨跌} | {来源} |")

    # 2. 供给信号
    if "供给信号" in market_data and market_data["供给信号"]:
        lines.append("\n⚡ 供给信号")
        for signal in market_data["供给信号"]:
            title = signal.get("标题", "")
            body = signal.get("正文", "")
            lines.append(f"{title}：{body}" if body else title)

    # 3. 争议风险
    if "争议风险" in market_data and market_data["争议风险"]:
        lines.append("\n⚠️ 争议风险")
        for risk in market_data["争议风险"]:
            title = risk.get("标题", "")
            body = risk.get("正文", "")
            lines.append(f"{title}：{body}" if body else title)

    return "\n".join(lines)

def generate_policy_content(items):
    """生成政策风向的Markdown内容（新格式：items为[{序号, 标题, 摘要, 来源, 日期}]）"""
    parts = []
    for item in items:
        if isinstance(item, dict):
            title = item.get("标题", "")
            summary = item.get("摘要", "")
            source = item.get("来源", "")
            date = item.get("日期", "")
            parts.append(f"**{title}**{summary}{source}{date}")
    return "\n\n".join(parts)

def generate_company_content(items):
    """生成企业动态的Markdown内容（**标题** 内容格式）"""
    return generate_policy_content(items)  # 格式相同

def generate_tech_content(items):
    """生成前沿与产品动态的Markdown内容"""
    return generate_policy_content(items)  # 格式相同

def generate_project_content(items):
    """生成项目与招标的Markdown内容"""
    return generate_policy_content(items)  # 格式相同

def generate_tips_content(tips_data, dept_name):
    """生成专属提示的Markdown内容（只输出summary字段）"""
    lines = []

    # 机会
    opportunities = tips_data.get("机会", [])
    if opportunities:
        for opp in opportunities:
            summary = opp.get("总结", "")
            lines.append(f"{summary}")
        lines.append("")  # 空行分隔

    # 风险
    risks = tips_data.get("风险", [])
    if risks:
        lines.append("**风险**：")
        for risk in risks:
            summary = risk.get("总结", "")
            lines.append(f"{summary}")
        lines.append("")  # 空行分隔

    # 行动建议
    suggestions = tips_data.get("行动建议", [])
    if suggestions:
        lines.append("**行动建议**：")
        for s in suggestions:
            summary = s.get("总结", "")
            lines.append(f"{summary}")
        lines.append("")  # 空行分隔

    # 重点关注
    focuses = tips_data.get("重点关注", [])
    if focuses:
        lines.append("**重点关注**：")
        for f in focuses:
            summary = f.get("总结", "")
            lines.append(f"{summary}")

    return "\n".join(lines).strip()

def convert_new_to_old_dept(new_data, dept_code):
    """将一个新格式JSON转换为旧格式的部门对象"""
    header = new_data.get("header", {})
    sections = new_data.get("sections", {})
    dept_name = header.get("事业部", "")

    # 提取基本信息
    report_date = header.get("报告时间", "")
    topnews_list = sections.get("今日关注", [])
    headline = topnews_list[0].get("标题", "") if topnews_list else f"{dept_name}早报"

    # 构建7个sections（旧格式）
    old_sections = []

    # 0. 今日关注
    topnews_items = sections.get("今日关注", [])
    old_sections.append({
        "dim": "topnews",
        "title": "今日关注",
        "name": "今日关注",
        "content": generate_topnews_content(topnews_items)
    })

    # 1. 市场行情
    market_data = sections.get("市场_价格", {})
    old_sections.append({
        "dim": "市场",
        "title": "市场行情",
        "name": "市场行情",
        "content": generate_market_content(market_data)
    })

    # 2. 政策风向
    policy_items = sections.get("政策_行业", [])
    old_sections.append({
        "dim": "政策",
        "title": "政策风向",
        "name": "政策风向",
        "content": generate_policy_content(policy_items)
    })

    # 3. 企业动态（加🔥 emoji）
    company_items = sections.get("企业动态", [])
    old_sections.append({
        "dim": "竞品",
        "title": "🔥 企业动态",
        "name": "🔥 企业动态",
        "content": generate_company_content(company_items)
    })

    # 4. 前沿与产品动态
    tech_items = sections.get("技术_产品", [])
    old_sections.append({
        "dim": "前沿",
        "title": "前沿与产品动态",
        "name": "前沿与产品动态",
        "content": generate_tech_content(tech_items)
    })

    # 5. 项目与招标
    project_items = sections.get("项目_招标", [])
    old_sections.append({
        "dim": "客户",
        "title": "项目与招标",
        "name": "项目与招标",
        "content": generate_project_content(project_items)
    })

    # 6. 专属提示
    tips_data = sections.get("专属提示", {})
    old_sections.append({
        "title": f"【{dept_name}专属提示】",
        "name": f"【{dept_name}专属提示】",
        "content": generate_tips_content(tips_data, dept_name)
    })

    # 构建部门对象（旧格式）
    dept_obj = {
        "name": dept_name,
        "subtitle": f"{dept_name}早报",
        "report_date": report_date,
        "window_start": report_date,
        "window_end": report_date,
        "headline": headline[:100] if headline else f"{dept_name}早报",
        "lead_judgment": "",  # 暂时为空
        "risk_tip": "；".join(item.get("总结", "") for item in tips_data.get("风险", [])) if tips_data else "",
        "summary": "；".join(item.get("总结", "") for item in tips_data.get("机会", [])) if tips_data else "",
        "sections": old_sections,
        "sectionsByDim": {},
        "total_events": sum(len(s.get("content", "").split("\n")) for s in old_sections)
    }

    return dept_obj

def main():
    # 解析命令行参数
    if len(sys.argv) < 2:
        date_str = datetime.now().strftime("%Y-%m-%d")
    else:
        date_str = sys.argv[1]

    if len(sys.argv) < 3:
        src_dir = r"C:\Users\1\Downloads\2026-05-19-9bu-reports-json"
    else:
        src_dir = sys.argv[2]

    print(f"[转换 v2] 日期: {date_str}")
    print(f"[转换 v2] 源目录: {src_dir}")
    print(f"[转换 v2] 目标目录: {REPORTS_DIR}")
    print()

    # 检查源目录
    if not os.path.exists(src_dir):
        print(f"[错误] 源目录不存在: {src_dir}")
        return False

    # 备份当前错误的文件（如果存在）
    target_file = os.path.join(REPORTS_DIR, f"{date_str}.json")
    if os.path.exists(target_file):
        backup_file = target_file + ".backup_wrong"
        import shutil
        shutil.copy2(target_file, backup_file)
        print(f"[备份] 已备份错误文件到: {backup_file}")

    # 读取所有新JSON文件并转换
    departments = {}
    for filename, dept_code in FILE_TO_DEPT.items():
        filepath = os.path.join(src_dir, filename)
        if not os.path.exists(filepath):
            print(f"[警告] 文件不存在: {filename}，跳过")
            continue

        try:
            with open(filepath, 'r', encoding='utf-8') as f:
                new_data = json.load(f)

            dept_obj = convert_new_to_old_dept(new_data, dept_code)
            departments[dept_code] = dept_obj
            print(f"[OK] 已转换: {filename} → {dept_code}")

        except Exception as e:
            print(f"[错误] 转换失败 {filename}: {e}")
            import traceback
            traceback.print_exc()

    if not departments:
        print("[错误] 没有成功转换任何部门")
        return False

    # 构建旧格式JSON
    old_data = {
        "date": date_str,
        "generated_at": datetime.now().isoformat(),
        "window_start": date_str,
        "window_end": date_str,
        "version": f"convert_new_to_old_v2.py - {date_str}",
        "total_divisions": len(departments),
        "departments": departments
    }

    # 保存为目标文件
    with open(target_file, 'w', encoding='utf-8') as f:
        json.dump(old_data, f, ensure_ascii=False, indent=2)

    print(f"\n[OK] 已保存: {target_file}")
    print(f"[统计] 部门数: {len(departments)}")

    # 更新 index.json
    index_file = os.path.join(REPORTS_DIR, "index.json")
    if os.path.exists(index_file):
        with open(index_file, 'r', encoding='utf-8') as f:
            index_data = json.load(f)

        if date_str not in index_data.get('available_dates', []):
            index_data['available_dates'].insert(0, date_str)

        index_data['latest_date'] = date_str
        index_data['generated_at'] = datetime.now().isoformat()
        index_data['total_reports'] = len(index_data.get('available_dates', []))

        with open(index_file, 'w', encoding='utf-8') as f:
            json.dump(index_data, f, ensure_ascii=False, indent=2)

        print(f"[OK] 已更新 index.json")
        print(f"[统计] 最新日期: {index_data['latest_date']}")
        print(f"[统计] 总报告数: {index_data['total_reports']}")

    print("\n[完成] 转换成功（v2）！")
    print(f"[提示] 请刷新浏览器 http://localhost:8888/index_v3.html 查看更新")

    return True

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)
